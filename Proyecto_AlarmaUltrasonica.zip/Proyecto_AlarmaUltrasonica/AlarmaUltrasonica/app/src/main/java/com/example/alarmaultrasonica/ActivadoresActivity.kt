package com.example.alarmaultrasonica

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.net.HttpURLConnection
import java.net.URL

class ActivadoresActivity : AppCompatActivity() {

    private val ipEsp32 = "192.168.4.1"
    private lateinit var txtEstadoActivador: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_activadores)

        txtEstadoActivador = findViewById(R.id.txtEstadoActivador)
        val btnLedOn = findViewById<Button>(R.id.btnLedOn)
        val btnLedOff = findViewById<Button>(R.id.btnLedOff)
        val btnVolver = findViewById<Button>(R.id.btnVolverActivadores)

        btnLedOn.setOnClickListener {
            enviarComando("/led/on")
        }

        btnLedOff.setOnClickListener {
            enviarComando("/led/off")
        }

        btnVolver.setOnClickListener {
            finish()
        }
    }

    private fun enviarComando(ruta: String) {
        txtEstadoActivador.text = "Enviando comando..."

        Thread {
            var conexion: HttpURLConnection? = null
            try {
                val url = URL("http://$ipEsp32$ruta")
                conexion = url.openConnection() as HttpURLConnection
                conexion.requestMethod = "GET"
                conexion.connectTimeout = 3000
                conexion.readTimeout = 3000

                val codigo = conexion.responseCode
                if (codigo == 200) {
                    val respuesta = conexion.inputStream.bufferedReader().use { it.readText() }
                    runOnUiThread {
                        txtEstadoActivador.text = respuesta
                    }
                } else {
                    runOnUiThread {
                        txtEstadoActivador.text = "Error HTTP: $codigo"
                    }
                }
            } catch (e: Exception) {
                runOnUiThread {
                    txtEstadoActivador.text = "No se pudo comunicar con ESP32"
                }
            } finally {
                conexion?.disconnect()
            }
        }.start()
    }
}
