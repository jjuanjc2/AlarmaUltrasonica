package com.example.alarmaultrasonica

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnMonitoreo = findViewById<Button>(R.id.btnMonitoreo)
        val btnActivadores = findViewById<Button>(R.id.btnActivadores)
        val btnConexion = findViewById<Button>(R.id.btnConexion)
        val btnCerrarSesion = findViewById<Button>(R.id.btnCerrarSesion)

        btnMonitoreo.setOnClickListener {
            startActivity(Intent(this, MonitoreoActivity::class.java))
        }

        btnActivadores.setOnClickListener {
            startActivity(Intent(this, ActivadoresActivity::class.java))
        }

        btnConexion.setOnClickListener {
            val intent = Intent(this, ConexionActivity::class.java)
            intent.putExtra("ORIGEN", "Alarma Ultrasónica")
            startActivity(intent)
        }

        btnCerrarSesion.setOnClickListener {
            val intent = Intent(this, LoginActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
        }
    }
}
