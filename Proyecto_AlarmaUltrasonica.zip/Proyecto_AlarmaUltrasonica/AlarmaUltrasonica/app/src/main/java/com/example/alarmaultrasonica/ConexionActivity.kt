package com.example.alarmaultrasonica

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.net.HttpURLConnection
import java.net.URL

class ConexionActivity : AppCompatActivity() {

    private val ipEsp32 = "192.168.4.1"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_conexion)

        val txtTituloConexion = findViewById<TextView>(R.id.txtTituloConexion)
        val txtEstadoConexion = findViewById<TextView>(R.id.txtEstadoConexion)
        val txtDispositivo = findViewById<TextView>(R.id.txtDispositivo)
        val btnWifi = findViewById<Button>(R.id.btnWifi)
        val btnDesconectar = findViewById<Button>(R.id.btnDesconectar)
        val btnVolver = findViewById<Button>(R.id.btnVolver)

        val origen = intent.getStringExtra("ORIGEN")
        txtTituloConexion.text = "CONEXIÓN WI-FI - ${origen ?: "Alarma Ultrasónica"}"

        btnWifi.setOnClickListener {
            txtEstadoConexion.text = "Estado: Verificando enlace Wi-Fi..."
            txtDispositivo.text = "Red: ESP32_AlarmaUltrasonica ($ipEsp32)"

            Thread {
                var conexion: HttpURLConnection? = null
                try {
                    val url = URL("http://$ipEsp32/")
                    conexion = url.openConnection() as HttpURLConnection
                    conexion.requestMethod = "GET"
                    conexion.connectTimeout = 3000
                    conexion.readTimeout = 3000

                    if (conexion.responseCode == 200) {
                        runOnUiThread {
                            txtEstadoConexion.text = "Estado: Modo Wi-Fi Conectado"
                            txtDispositivo.text = "ESP32_AlarmaUltrasonica: $ipEsp32"
                        }
                    } else {
                        runOnUiThread {
                            txtEstadoConexion.text = "Estado: Error HTTP ${conexion.responseCode}"
                        }
                    }
                } catch (e: Exception) {
                    runOnUiThread {
                        txtEstadoConexion.text = "Estado: Sin respuesta de $ipEsp32"
                    }
                } finally {
                    conexion?.disconnect()
                }
            }.start()
        }

        btnDesconectar.setOnClickListener {
            txtEstadoConexion.text = "Estado: Sin conexión"
            txtDispositivo.text = "Dispositivo: --"
        }

        btnVolver.setOnClickListener {
            finish()
        }
    }
}
