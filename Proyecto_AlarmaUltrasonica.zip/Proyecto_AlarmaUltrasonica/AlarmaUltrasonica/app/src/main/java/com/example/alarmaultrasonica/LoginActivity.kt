package com.example.alarmaultrasonica

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class LoginActivity : AppCompatActivity() {

    private lateinit var edtUsuario: EditText
    private lateinit var edtPassword: EditText
    private lateinit var btnIngresar: Button
    private lateinit var txtMensajeLogin: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        edtUsuario = findViewById(R.id.edtUsuario)
        edtPassword = findViewById(R.id.edtPassword)
        btnIngresar = findViewById(R.id.btnIngresar)
        txtMensajeLogin = findViewById(R.id.txtMensajeLogin)

        btnIngresar.setOnClickListener {
            validarIngreso()
        }
    }

    private fun validarIngreso() {
        val usuario = edtUsuario.text.toString().trim()
        val password = edtPassword.text.toString()

        if (usuario.isEmpty() || password.isEmpty()) {
            txtMensajeLogin.text = "Complete usuario y contraseña"
            return
        }

        if (usuario == "admin" && password == "12345") {
            txtMensajeLogin.text = ""
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        } else {
            txtMensajeLogin.text = "Credenciales incorrectas"
        }
    }
}
