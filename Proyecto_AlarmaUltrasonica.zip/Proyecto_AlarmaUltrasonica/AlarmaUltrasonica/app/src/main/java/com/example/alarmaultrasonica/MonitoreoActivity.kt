package com.example.alarmaultrasonica

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.net.HttpURLConnection
import java.net.URL

class MonitoreoActivity : AppCompatActivity() {

    private val ipEsp32 = "192.168.4.1"

    private lateinit var txtDato1: TextView
    private lateinit var txtDato2: TextView
    private lateinit var txtDatoRecibido: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_monitoreo)

        txtDato1 = findViewById(R.id.txtDato1)
        txtDato2 = findViewById(R.id.txtDato2)
        txtDatoRecibido = findViewById(R.id.txtDatoRecibido)

        val btnActualizar = findViewById<Button>(R.id.btnActualizar)
        val btnVolver = findViewById<Button>(R.id.btnVolverMonitoreo)

        txtDato1.text = "Distancia: -- cm"
        txtDato2.text = "Proximidad: --"

        btnActualizar.setOnClickListener {
            consultarProximidad()
        }

        btnVolver.setOnClickListener {
            finish()
        }
    }

    private fun consultarProximidad() {
        txtDatoRecibido.text = "Estado: Consultando..."

        Thread {
            var conexion: HttpURLConnection? = null
            try {
                val url = URL("http://$ipEsp32/sensor")
                conexion = url.openConnection() as HttpURLConnection
                conexion.requestMethod = "GET"
                conexion.connectTimeout = 3000
                conexion.readTimeout = 3000

                if (conexion.responseCode == 200) {
                    val respuesta = conexion.inputStream.bufferedReader().use { it.readText() }
                    val datos = respuesta.split(";")

                    if (datos.size >= 2) {
                        val distancia = datos[0]
                        val estado = datos[1].trim()

                        val textoEstado = if (estado == "OBJETO_CERCA")
                            "Objeto cercano (¡ALARMA DE INTRUSIÓN!)"
                        else
                            "Sin obstáculo (Perímetro seguro)"

                        runOnUiThread {
                            txtDato1.text = "Distancia: $distancia cm"
                            txtDato2.text = "Proximidad: $textoEstado"
                            txtDatoRecibido.text = "Estado: Datos recibidos"
                        }
                    } else {
                        mostrarError("Respuesta inválida")
                    }
                } else {
                    mostrarError("Error HTTP: ${conexion.responseCode}")
                }
            } catch (e: Exception) {
                mostrarError("Sin conexión con ESP32")
            } finally {
                conexion?.disconnect()
            }
        }.start()
    }

    private fun mostrarError(mensaje: String) {
        runOnUiThread {
            txtDatoRecibido.text = "Estado: $mensaje"
        }
    }
}
