#include <WiFi.h>
#include <WebServer.h>

const char* ssid = "ESP32_AlarmaUltrasonica";
const char* password = "12345678";

WebServer server(80);

const int TRIG = 5;
const int ECHO = 18; 

const int LED = 23;

float medirDistancia() {
  digitalWrite(TRIG, LOW);
  delayMicroseconds(2);

  digitalWrite(TRIG, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG, LOW);

  long duracion = pulseIn(ECHO, HIGH, 30000);

  if (duracion == 0) {
    return -1;
  }

  float distancia = duracion * 0.0343 / 2.0;
  return distancia;
}

void paginaPrincipal() {
  server.send(200, "text/plain", "ESP32 AlarmaUltrasonica HC-SR04 funcionando");
}

void encenderLed() {
  digitalWrite(LED, HIGH);
  server.send(200, "text/plain", "ALARMA ENCENDIDA (LED ON)");
}

void apagarLed() {
  digitalWrite(LED, LOW);
  server.send(200, "text/plain", "ALARMA APAGADA (LED OFF)");
}

void leerSensor() {
  float distancia = medirDistancia();

  if (distancia < 0) {
    server.send(500, "text/plain", "ERROR_SENSOR");
    return;
  }

  String estado;
  if (distancia <= 20.0) {
    estado = "OBJETO_CERCA";
  } else {
    estado = "SIN_OBSTACULO";
  }

  String respuesta = String(distancia, 1) + ";" + estado;
  server.send(200, "text/plain", respuesta);
}

void consultarEstado() {
  String estadoAlarma = (digitalRead(LED) == HIGH) ? "ALARMA ENCENDIDA" : "ALARMA APAGADA";
  float distancia = medirDistancia();

  if (distancia >= 0) {
    String prox = (distancia <= 20.0) ? "OBJETO_CERCA" : "SIN_OBSTACULO";
    server.send(200, "text/plain", estadoAlarma + " | Dist: " + String(distancia, 1) + " cm (" + prox + ")");
  } else {
    server.send(200, "text/plain", estadoAlarma);
  }
}

void setup() {
  Serial.begin(115200);

  pinMode(TRIG, OUTPUT);
  pinMode(ECHO, INPUT);
  pinMode(LED, OUTPUT);
  digitalWrite(LED, LOW);

  WiFi.softAP(ssid, password);

  Serial.println();
  Serial.println("========================================");
  Serial.println("Proyecto: ESP32_AlarmaUltrasonica");
  Serial.println("========================================");
  Serial.print("Red Wi-Fi: ");
  Serial.println(ssid);
  Serial.print("IP del ESP32: ");
  Serial.println(WiFi.softAPIP()); 

  server.on("/", paginaPrincipal);
  server.on("/sensor", leerSensor);
  server.on("/estado", consultarEstado);
  server.on("/led/on", encenderLed);
  server.on("/led/off", apagarLed);

  server.begin();
  Serial.println("Servidor HTTP de AlarmaUltrasonica iniciado");
}

void loop() {
  server.handleClient();
}
